<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_format() );

			// End the loop.
			endwhile;
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
				'next_text'          => __( 'Next page', 'twentysixteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		<script type="text/javascript">

				jQuery(document).ready(function()
				{
				    jQuery("#game_increment").click(function()
				    {
						//e.preventDefault();
						
				        var n = jQuery("#game_id");

				        if(jQuery(n).val()=='like')
				        //if (jQuery(this).val()=='like') 
				        {
				        	//jQuery(n).append();

				        	//var add = n.val( Number(n.val())+1 ); // Have to type the .val() response to a number instead of a string.
				        	//jQuery(this).val('Unlike');
				        	//var add = n.val() +1 ;
				        	jQuery(n).append();
				        }
				        /*else 
				        {	
				        	jQuery(this).val('like');
				        	n.val( Number(n.val())-1 );
				        }*/
										
						//jQuery('#increment').val('Unlike');	

						//var count = jQuery('#blogid').value;	
						//var submit = jQuery('#increment').value;	

						/*jQuery.ajax({
							type: 'POST',
							url: 'single-movie-ajax.php',
							data: {
								count:count,
								submit:submit,

							},
							success:function(data,textStatus,XMLHTTPRequest){
								console.log(data);
								console.log(textStatus);
								console.log(XMLHTTPRequest);
							},
							error:function(XMLHTTPRequest,textStatus,errorThrown){
								console.log(errorThrown);
								console.log(textStatus);
								console.log(XMLHTTPRequest);
							}

						});	*///ajax end

				    }); 	//on click end

				});	//doc ready end


			</script>
			<style type="text/css">
			#increment {
				width: 8%;
				font-size: 11px;
			}

			</style>
			Total Likes : <?php echo get_post_meta(get_the_ID(),'like',true);?>
			<form action="" method="POST">
				<input type="text" id="game_id" name="game_id" value="<?php echo get_the_ID();?>">
				<button>JOIN+</button>
				<input type="submit" id="game_increment" value="Like" name="game_increment" />
			</form>
		<?php
		//var_dump($_POST);



		if (isset($_POST['game_increment'])) 
		{
			//$countLikes = get_post_meta($_POST['blog'],'like',true);//

			$likesgame = get_post_meta(get_the_ID(),'like',true);

			//var_dump($countLikes);
			
			$game_id = $_POST['game_id'];
			$meta_key = 'like';
			$meta_value = ++$likesgame;


			$new_game = update_post_meta($game_id,$meta_key,$meta_value);

		}



		/*function post_meta($value)
		{
			$post_id = the_ID();
			$meta_key = 'like';
			$meta_value = $_POST['count'];
			

			$new_game = add_post_meta($post_id,$meta_key,$value);
			
			//wp_insert_post($new_game);
		}*/


		?>


		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
