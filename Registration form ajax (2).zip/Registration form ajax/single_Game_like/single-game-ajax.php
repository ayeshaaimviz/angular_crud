<?php

add_action('wp_ajax_LikeGame','LikeGame');

function LikeGame()
{
	$res = array();
	$counter=wp_strip_all_tags($_POST['count']);
	$add = wp_strip_all_tags($_POST['add'])''
	print_r($counter);

	//$_POST['submit']
		
			$countLikes = get_post_meta($_POST['add'],'like',true);
			//var_dump($countLikes);
			//$post_id = get_current_user_id();
			$post_id = wp_strip_all_tags($_POST['count']);
			//$meta_key = 'like';
			//$meta_value = ++$countLikes;
			$res['like'] = 'like';
			$res['count']= ++$countLikes;

			//$new_post = update_post_meta($post_id,$meta_key,$meta_value);

			//$res['submit'] = update_post_meta($post_id,$meta_key,$meta_value);

			$res['submit'] = update_post_meta($post_id,$res['like'],$res['count']);

			//print(json_encode($res));
			/*if ($res['submit']==true) 
			{
				unset($res[''])
			}*/

			//print_r('aisha');
			//var_dump($new_post);



			//return $new_post;
			//wp_insert_post($new_post);
			//post_meta($_POST['count']);
		//}

	/*$pid = wp_strip_all_tags($_POST['blogid']);
	$res['likes'] = get_post_meta($pid,'like',true);
	$res['asd'] ='asdasd';
	*/
	print_r(json_encode($res));
	die();

}


?>