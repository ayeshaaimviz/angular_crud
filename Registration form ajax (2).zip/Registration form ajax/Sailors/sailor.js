jQuery(document).ready(function()
{
	jQuery('#select_city').hide();

	jQuery('.country').on('change',function()
	{	
		jQuery('select_city').show();
		var country_id = jQuery(this).val();
		//jQuery(".city").find('option').remove();

		jQuery.ajax
		({
			type:'POST',
			url:ajax_call.ajax_sailor_url,
			data: {
				action:'getcity',
				country_id:country_id
			},



		});




	});











});
