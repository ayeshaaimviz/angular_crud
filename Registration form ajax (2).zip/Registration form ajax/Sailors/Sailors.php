<?php
ob_start();
/**
 * @package Sailors
 * @version 4.4
 */
/*
Plugin Name: Sailors
Plugin URI: https://wordpress.org/plugins/Sailors/
Description: I just need something simple that will allow users easy access from the front end to manage their posts. I've been trying plugin after plugin and adding things to my short code creator but nothing works the way I need it to.
Version: 4.5
Author URI: http://localhost/
*/

//create custom post
//Elaborate:
add_action( 'init', 'codex_sailor_init' );
/**
 * Register a sailor post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function codex_sailor_init() {
	$labels = array(
		'name'               => _x( 'Sailors', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Sailor', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Sailors', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Sailor', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'sailor', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Sailor', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Sailor', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Sailor', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Sailor', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Sailors', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Sailors', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Sailors:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No Sailors found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No Sailors found in Trash.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
                'description'        => __( 'Description.', 'your-plugin-textdomain' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'sailor' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
	);

	register_post_type( 'sailor', $args );
}

//Customizing the messages:
add_filter( 'post_updated_messages', 'codex_sailor_updated_messages' );
/**
 * Book update messages.
 *
 * See /wp-admin/edit-form-advanced.php
 *
 * @param array $messages Existing post update messages.
 *
 * @return array Amended post update messages with new CPT update messages.
 */
function codex_sailor_updated_messages( $messages ) {
	$post             = get_post();
	$post_type        = get_post_type( $post );
	$post_type_object = get_post_type_object( $post_type );

	$messages['sailor'] = array(
		0  => '', // Unused. Messages start at index 1.
		1  => __( 'Sailor updated.', 'your-plugin-textdomain' ),
		2  => __( 'Custom field updated.', 'your-plugin-textdomain' ),
		3  => __( 'Custom field deleted.', 'your-plugin-textdomain' ),
		4  => __( 'Sailor updated.', 'your-plugin-textdomain' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Sailor restored to revision from %s', 'your-plugin-textdomain' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		6  => __( 'Sailor published.', 'your-plugin-textdomain' ),
		7  => __( 'Sailor saved.', 'your-plugin-textdomain' ),
		8  => __( 'Sailor submitted.', 'your-plugin-textdomain' ),
		9  => sprintf(
			__( 'Sailor scheduled for: <strong>%1$s</strong>.', 'your-plugin-textdomain' ),
			// translators: Publish box date format, see http://php.net/date
			date_i18n( __( 'M j, Y @ G:i', 'your-plugin-textdomain' ), strtotime( $post->post_date ) )
		),
		10 => __( 'Sailor draft updated.', 'your-plugin-textdomain' )
	);

	if ( $post_type_object->publicly_queryable ) {
		$permalink = get_permalink( $post->ID );

		$view_link = sprintf( ' <a href="%s">%s</a>', esc_url( $permalink ), __( 'View sailor', 'your-plugin-textdomain' ) );
		$messages[ $post_type ][1] .= $view_link;
		$messages[ $post_type ][6] .= $view_link;
		$messages[ $post_type ][9] .= $view_link;

		$preview_permalink = add_query_arg( 'preview', 'true', $permalink );
		$preview_link = sprintf( ' <a target="_blank" href="%s">%s</a>', esc_url( $preview_permalink ), __( 'Preview sailor', 'your-plugin-textdomain' ) );
		$messages[ $post_type ][8]  .= $preview_link;
		$messages[ $post_type ][10] .= $preview_link;
	}

	return $messages;
}


//Adding contextual help:
//display contextual help for Sailors

function codex_add_help_text( $contextual_help, $screen_id, $screen ) {
  //$contextual_help .= var_dump( $screen ); // use this to help determine $screen->id
  if ( 'sailor' == $screen->id ) {
    $contextual_help =
      '<p>' . __('Things to remember when adding or editing a sailor:', 'your_text_domain') . '</p>' .
      '<ul>' .
      '<li>' . __('Specify the correct genre such as Mystery, or Historic.', 'your_text_domain') . '</li>' .
      '<li>' . __('Specify the correct writer of the sailor.  Remember that the Author module refers to you, the author of this sailor review.', 'your_text_domain') . '</li>' .
      '</ul>' .
      '<p>' . __('If you want to schedule the sailor review to be published in the future:', 'your_text_domain') . '</p>' .
      '<ul>' .
      '<li>' . __('Under the Publish module, click on the Edit link next to Publish.', 'your_text_domain') . '</li>' .
      '<li>' . __('Change the date to the date to actual publish this article, then click on Ok.', 'your_text_domain') . '</li>' .
      '</ul>' .
      '<p><strong>' . __('For more information:', 'your_text_domain') . '</strong></p>' .
      '<p>' . __('<a href="http://codex.wordpress.org/Posts_Edit_SubPanel" target="_blank">Edit Posts Documentation</a>', 'your_text_domain') . '</p>' .
      '<p>' . __('<a href="http://wordpress.org/support/" target="_blank">Support Forums</a>', 'your_text_domain') . '</p>' ;
  } elseif ( 'edit-sailor' == $screen->id ) {
    $contextual_help =
      '<p>' . __('This is the help screen displaying the table of Sailors blah blah blah.', 'your_text_domain') . '</p>' ;
  }
  return $contextual_help;
}
add_action( 'contextual_help', 'codex_add_help_text', 10, 3 );


//create sailors post
/*
add_shortcode('hello','user_dashboard');
function user_dashboard()
{
	print_r("Hello...Dashboard");
}
*/
add_shortcode('add_sailor','add_sailor');

function add_sailor()
{	
	global $wpdb;
	$country = $wpdb->get_results('SELECT * FROM wp_country');
	$city = $wpdb->get_results('SELECT * FROM wp_city');
	?>
<!-- 	<option value="<?php echo $key->id; ?>"><?php echo $key->city_name; ?> </option> -->
	<form method="POST" action="" accept-charset="utf-8">
		<!-- <label>My Name </label>
		<input type="text" name="my_name" id="my_name" placeholder="My Name" > </br></br> -->

		<label>First Name </label>
		<input type="text" name="first_name" id="first_name" placeholder="First Name" value=""> </br></br>

		<label>Last Name </label>
		<input type="text" name="last_name" id="last_name" placeholder="Last Name"  value=""> </br></br>

		<label>User Name </label>
		<input type="text" name="user_name" id="user_name" placeholder="User Name"> </br></br>

		<label>Full Name </label>
		<input type="text" name="full_name" id="full_name" placeholder="Full Name"> </br></br>

		<label>Email Address </label>
		<input type="text" name="email" id="email" placeholder="Email Address"> </br></br>

		<label>Phone No </label>
		<input type="text" name="phone_no" id="phone_no" placeholder="Phone No" > </br></br>

		<label>Address</label>
		<input type="text" name="address" id="address" placeholder="Address" > </br></br>

		<label>Date of Birth</label>
		<input type="text" name="date_of_birth" id="date_of_birth" placeholder="Date-of-Birth"> </br></br>

		<label>N.I.C</label>
		<input type="text" name="nic" id="nic" placeholder="NIC" > </br></br>

		<label>License No</label>
		<input type="text" name="license_no" id="license_no" placeholder="Your License No" > </br></br>

		<select name="country" id="select_country" class="country">
			<option value="">Select Your Country</option>
			<?php
			foreach ($country as $key) 
			{
				?>
				<option value="<?php echo $key->id; ?>"><?php echo $key->country_name; ?> </option>
				<?php
			}
		 	?>
		</select></br></br>

		<select name="city">
			<option value="">Select Your City</option>
			<?php
			foreach ($city as $key) 
			{
				?>
				<option value="<?php echo $key->id; ?>"><?php echo $key->city_name; ?></option>
				<?php
			}
			?>
		</select></br></br>


		<label>Feature Image</label>
		<input type="file" name="image" id="image" > </br></br>

		<label>Description </label>
		<input type="text" name="desc" id="desc" placeholder="Write about sailor..." > </br></br>

		<input type="submit" name="submit" value="Submit">
	</form>

	<?php

	if (isset($_POST['submit'])) 	
	{
		/*echo "I'm working";
		var_dump($_POST['submit']);
		echo "<br>";*/

		$first_name = wp_strip_all_tags($_POST['first_name']);
		/*var_dump($first_name);
		echo "<br>";*/

		$last_name = wp_strip_all_tags($_POST['last_name']);
		/*var_dump($last_name);
		echo "<br>";*/

		$user_name = wp_strip_all_tags($_POST['user_name']);
		/*var_dump($user_name);
		echo "<br>";*/

		$full_name = wp_strip_all_tags($_POST['full_name']);	
		$title = $full_name;	//full name = POST_title
		/*var_dump($title);
		echo "<br>";*/

		$email = wp_strip_all_tags($_POST['email']);
		/*var_dump($email);
		echo "<br>";*/

		$phone_no = wp_strip_all_tags($_POST['phone_no']);
		/*var_dump($phone_no);
		echo "<br>";*/

		$address = wp_strip_all_tags($_POST['address']);
		/*var_dump($address);
		echo "<br>";*/

		$date_of_birth = wp_strip_all_tags($_POST['date_of_birth']);
		/*var_dump($date_of_birth);
		echo "<br>";
*/
		$nic = wp_strip_all_tags($_POST['nic']);
		/*var_dump($nic);
		echo "<br>";*/

		$license_no = wp_strip_all_tags($_POST['license_no']);
		/*var_dump($license_no);
		echo "<br>";*/

		$country = wp_strip_all_tags($_POST['country']);
		/*var_dump($country);
		echo "<br>";*/

		$city = wp_strip_all_tags($_POST['city']);
		/*var_dump($city);
		echo "<br>";*/

		$desc = wp_strip_all_tags($_POST['desc']);
		$content = $desc;
		/*var_dump($content);
		echo "<br>";*/

		/*echo $this->insert_sailor($_REQUEST['full_name'],$_REQUEST['desc']);
		echo "Blog Created";
		echo "<br>";*/

		$post_id = wp_insert_post(
        array(
            'post_content'   => $content,
            'post_name'      => $title,
            'post_title'     => $title,
            'post_status'    => 'publish',
            'post_type'      => 'Sailor',
            'ping_status'    => 'closed',
            'comment_status' => 'closed',
            )
    	);
    	var_dump($post_id);
    	echo "<br>";

		$first_key = 'first_name';
		$value = $first_name;
		$f_name = add_post_meta($post_id,$first_key,$value );
		print_r($f_name); 
		echo "<br>";

		$last_key = 'last_name';
		$value = $last_name;
		$l_name = add_post_meta($post_id,$last_key,$value );
		print_r($l_name); 
		echo "<br>";

		$user_key = 'user_name';
		$value = $user_name;
		$f_name = add_post_meta($post_id,$user_key,$value );
		print_r($f_name); 
		echo "<br>";

		$email_key = 'email_address';
		$value = $email;
		$emal_add = add_post_meta($post_id,$email_key,$value );
		print_r($emal_add); 
		echo "<br>";

		$phone_key = 'phone_no';
		$value = $phone_no;
		$phone = add_post_meta($post_id,$phone_key,$value );
		print_r($phone); 
		echo "<br>";

		$address_key = 'address';
		$value = $address;
		$address = add_post_meta($post_id,$address_key,$value );
		print_r($address); 
		echo "<br>";

		$date_key = 'date_of_birth';
		$value = $date_of_birth;
		$dob = add_post_meta($post_id,$date_key,$value );
		print_r($dob); 
		echo "<br>";

		$nic_key = 'nic';
		$value = $nic;
		$n_i_c = add_post_meta($post_id,$nic_key,$value );
		print_r($n_i_c);
		echo "<br>";

		$license_key = 'license_no';
		$value = $license_no;
		$license = add_post_meta($post_id,$license_key,$value );
		print_r($license);
		echo "<br>";

		$country_key = 'country';
		$value = $country;
		$country_meta = add_post_meta($post_id,$country_key,$value );
		print_r($country_meta);
		echo "<br>";

		$city_key = 'city';
		$value = $city;
		$city_meta = add_post_meta($post_id,$city_key,$value );
		print_r($city_meta);
		echo "<br>";


    	echo "Blog Created";
		echo "<br>";



	}	//end if isset
}	//end function

register_activation_hook( __FILE__,'add_sailor' );








?>