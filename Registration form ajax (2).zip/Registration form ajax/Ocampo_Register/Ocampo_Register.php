<?php
ob_start();

/**
 * @package ocampo_Register
 * @version 4.4
 */
/*
Plugin Name: ocampo_Register
Plugin URI: https://wordpress.org/plugins/ocampo_Register/
Description: Sign up for a BAFA account to join our games. Contact Form 7 can manage multiple contact forms, plus you can customize the form and the mail contents flexibly with simple markup.
Version: 4.4
Author URI: http://localhost/
*/
function ajax_ocampo_js() 
	{
	 wp_enqueue_script('my-ocampo', plugin_dir_url( __FILE__ ).'ocampo.js', array('jquery')); 	// use for file include
	 wp_localize_script('my-ocampo', 'ajax_call_ocampo', array('ajaxurl_ocampo' => admin_url('admin-ajax.php')));	//use for define global variable
	}

	add_action('wp_enqueue_scripts', 'ajax_ocampo_js');

add_shortcode('ocampo_register','ocampo_register');

//add_action('wp_ajax_ocampo_register','ocampo_register');

function ocampo_register()
{
	?>
	<form>
		<label>USERNAME:*</label>
		<input type="text" name="ocampo_username" id="ocampo_username" maxlength="30" >

		<label>EMAIL ADDRESS:*</label>
		<input type="text" name="ocampo_email" id="ocampo_email">

		<label>PASSWORD:*</label>
		<input type="password" name="ocampo_pass" id="ocampo_pass">

		<label>PASSWORD(AGAIN):*</label>
		<input type="password" name="ocampo_re_pass" id="ocampo_re_pass">

		<input type="submit" name="ocampo_submit" id="ocampo_submit" value="SIGN UP">
	</form>
	<?php
}



?>