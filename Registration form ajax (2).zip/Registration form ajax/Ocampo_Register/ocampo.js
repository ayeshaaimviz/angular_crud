
jQuery(document).ready(function()
{
	jQuery('#ocampo_submit').click(function()
	{
		alert('hi');
		console.log('hello');

	});

});