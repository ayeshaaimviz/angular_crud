<?php

add_action('wp_ajax_likeMe','likeMe');

function likeMe()
{
	$res = array();
	$counter=wp_strip_all_tags($_POST['count']);
	$add = wp_strip_all_tags($_POST['add'])''
	print_r($counter);

	//$_POST['submit']
		
			$countLikes = get_post_meta($_POST['add'],'like',true);
			//var_dump($countLikes);
			//$post_id = get_current_user_id();
			$post_id = wp_strip_all_tags($_POST['count']);
			//$meta_key = 'like';
			//$meta_value = ++$countLikes;
			$res['like'] = 'like';
			$res['count']= ++$countLikes;

			//$new_post = update_post_meta($post_id,$meta_key,$meta_value);

			//$res['submit'] = update_post_meta($post_id,$meta_key,$meta_value);

			$res['submit'] = update_post_meta($post_id,$res['like'],$res['count']);

			//print(json_encode($res));
			/*if ($res['submit']==true) 
			{
				unset($res[''])
			}*/

			//print_r('aisha');
			//var_dump($new_post);



			//return $new_post;
			//wp_insert_post($new_post);
			//post_meta($_POST['count']);
		//}

	/*$pid = wp_strip_all_tags($_POST['blogid']);
	$res['likes'] = get_post_meta($pid,'like',true);
	$res['asd'] ='asdasd';
	*/
	print_r(json_encode($res));
	die();

	/*$ip = get_ipaddress();
	
	if($res['likes']!=false){
		if(($key = array_search($ip, $res['likes'])) !== false) {
	   		unset($res['likes'][$key]);		
		}else{
			array_push($res['likes'],$ip);
		}		
	}else{
		$res['likes'] = array($ip);
	//	$res['likes'] = serialize($res['likes'] );
	}
	
	$res['res'] = update_post_meta($pid,'like',$res['likes']);
	
	print_r(json_encode($res));
	die();*/
}

### Function: Get IP Address
/*if(!function_exists('get_ipaddress')) {
	function get_ipaddress() {
		if (empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
			$ip_address = $_SERVER["REMOTE_ADDR"];
		} else {
			$ip_address = $_SERVER["HTTP_X_FORWARDED_FOR"];
		}
		if(strpos($ip_address, ',') !== false) {
			$ip_address = explode(',', $ip_address);
			$ip_address = $ip_address[0];
		}
		return esc_attr($ip_address);
	}
}*/
?>