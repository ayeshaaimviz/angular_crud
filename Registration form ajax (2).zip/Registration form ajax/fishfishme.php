<?php
ob_start();
/**
 * @package Fishme_Register
 * @version 4.4
 */
/*
Plugin Name: Fishme_Register
Plugin URI: https://wordpress.org/plugins/Fishme_Register/
Description: Contact Form 7 can manage multiple contact forms, plus you can customize the form and the mail contents flexibly with simple markup.
Version: 4.4
Author URI: http://localhost/
*/

/*class Fishme_Register
{
	function __construct()
	{
		$this->make_shortcode();
	}
*/
	/*function wp_db()
	{
		global $wpdb;
		$res = $wpdb->get_results('select state_name from wp_state');
		print($res);
		foreach ($res as $key) 
		{
			?>
			<option value="<?php echo $key->state_name; ?>"> <?php echo $key->state_name; ?> </option>
			<?php
		}
	}*/

	function create_form()
	{
		global $wpdb;
		$state = $wpdb->get_results('select state_name from wp_state');
		$country = $wpdb->get_results('select country_name from wp_country');
		$city = $wpdb->get_results('select city_name from wp_city');
		?>
		<script type="text/javascript">
		jQuery(document).ready(function()
		{
			jQuery('#select_state').hide();
			jQuery('#select_city').hide();

			jQuery('#select_country').change(function()
			{	
				jQuery('#select_state').show();
				//var id = $(this).val();
				var country_id = jQuery('#select_state').val();
				
				
				jQuery.ajax({
					type: 'POST',
					//url: 'my-ajax.php',
					url: '<?php $this->ajax_path(); ?>',
					data: {
						country_id:country_id,
						action:'getstate',
						
					},

					success:function(data,textStatus,XMLHTTPRequest){
						console.log(data);
						jQuery('#select_state').append(data);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown){
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					}
				});
			});


			jQuery("#select_state").change(function()
			{
				jQuery("#select_city").show();
				var city_id = jQuery("#select_city").val();
				//$("#select_city").css("display:block;");
				
			
				jQuery.ajax
				({
					type: 'POST',
					//url: 'my-ajax.php',
					url: '<?php $this->ajax_path(); ?>',
					data: {
						city_id: city_id,
						action: 'getcity',
						
					},

					success:function(data,textStatus,XMLHTTPRequest){
						console.log(data);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown){
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					} 
				});
			});

		});
		</script>
		<form class="ink_form" method="POST" accept-charset="utf-8">
		<label> Company Name </label>
			<input type="text" name="comp_name" id="comp_name" placeholder="Charter Company Name" required="required" > </br></br>
			<label> Full Name</label>
			 <input type="text" name="full_name" id="full_name" placeholder="Full Name" required="required"  > </br></br>
			<label>Email </label>
			 <input type="text" name="email" id="email" placeholder="Email" required="required"> </br></br>
			<label> Telephone </label>
			 <input type="text" name="phone" id="phone" placeholder="Telephone" required="required"> </br></br>
			 

			<!-- <label> Select Country</label> -->
			<select name="country" id="select_country" class="country">
				<option value="">Select Your Country</option>
				<?php
				foreach ($country as $key) 
				{
					?>
					<option value="<?php echo $key->country_name; ?>"><?php echo $key->country_name; ?> </option>
					<?php
				}
			 	?>
			</select></br></br>

			<!-- <label> Select State</label> -->
			<select name="state" id="select_state" class="state">
				<option selected="selected" value="">Select Your State</option>
				<?php
				/*foreach ($state as $key) 
				{
					?>
					<option value="<?php echo $key->state_name; ?>"><?php echo $key->state_name; ?> </option>
					<?php
				}*/
			 	?>
			</select>	</br></br>

			<!-- <label> Select City</label> -->
			<select name="city" id="select_city" class="city">
				<option selected="selected" value="">Select Your City</option>
				<?php
				/*foreach ($city as $key) 
				{
					?>
					<option value="<?php echo $key->city_name; ?>"><?php echo $key->city_name; ?> </option>
					<?php
				}*/
			 	?>
				
			</select></br></br>
			<label>	Address</label>
		 	<input type="text" name="address" id="address" placeholder="Address" required="required"> </br></br>
			<label> Password</label>
			 <input type="password" name="pass" id="pass" placeholder="Password" required="required"> </br> </br>
			<label>Repeat Password </label>
			<input type="password" name="re_pass" id="re_pass" placeholder="Repeat Password" required="required"> </br> </br>

			<input type="submit" name="submit" value="Submit" >
		</form>


		<?php
		/*if (isset($_POST['submit'])) 
		{
			$company = wp_strip_all_tags($_POST['comp_name']);
			$full_name = wp_strip_all_tags($_POST['full_name']);
			$email = wp_strip_all_tags($_POST['email']);
			$phone = wp_strip_all_tags($_POST['phone']);
			$state = wp_strip_all_tags($_POST['state']);
			$country = wp_strip_all_tags($_POST['country']);
			$address = wp_strip_all_tags($_POST['address']);
			$pass = wp_strip_all_tags($_POST['pass']);


			$users = array(
					'display_name' => $full_name,
					'user_email' => $email,
					'user-pass' => $pass,
				);
			$user_id = wp_insert_user($users);

			//for state
			

		}*/	// if isset end


	} //end function

	add_shortcode('create_form', 'create_form');

	/*public function make_shortcode() 
	{
		add_shortcode('create_form', array($this,'create_form') );
		add_shortcode('path', array($this,'ajax_path') );
		//add_shortcode('wp_db', array($this,'wp_db') );
		//add_shortcode('create_form','create_form' );
	}*/

	function ajax_path()
	{
		/*$x = plugin_basename( __FILE__ );
		echo $x;
		echo "<br>";

		$plugins_url = plugins_url();
		echo $plugins_url;	
		echo "<br>";*/

		$url = plugin_dir_url( __FILE__  );
		return $url."my-ajax.php" ;
	}

	add_shortcode('path','ajax_path');

/*}

$register = new Fishme_Register();*/


?>