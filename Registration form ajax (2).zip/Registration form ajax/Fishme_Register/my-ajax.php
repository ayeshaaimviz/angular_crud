<?php
$res = array();
$res['country_id'] = (isset($_POST['country_id']))?$_POST['country_id']:'';


switch($res['country_id'])
{
	case 'getstate':
        if($_POST['country_id'])
        {
            $id=$_POST['country_id'];
            global $wpdb;
            $country = $wpdb->get_results('select * from wp_state WHERE country_id='$id);
            
            foreach ($country as $key => $value) 
            {
                ?>
                    <option value="<?php echo $key->id; ?>"><?php echo $key->country_name; ?></option>
                <?php
            }
        }	
        break;

    case 'getcity':
        if($_POST['city_id'])
        {
            $country_id=$_POST['country_id'];
            global $wpdb;
            $country = $wpdb->get_results('select * from wp_city WHERE state_id='$id);
            
            foreach ($country as $key => $value) 
            {
                ?>
                    <option value="<?php echo $key->id; ?>"><?php echo $key->city_name; ?></option>
                <?php
            }       
        }
        
    default:
	        echo "Nothing to Display!";
}

?>