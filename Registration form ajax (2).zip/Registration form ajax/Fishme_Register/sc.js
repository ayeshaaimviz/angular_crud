
		jQuery(document).ready(function()
		{
			jQuery('#select_state').hide();
			jQuery('#select_city').hide();
			//var ajaxurl = '<?php echo admin_url("admin-ajax.php"); ?>';
			jQuery('.country').on('change',function(){
			

				jQuery('#select_state').show();
				var country_id = jQuery(this).val();
				jQuery.ajax
				({
					type: 'POST',
					url: ajax_call.ajaxurl,
					data: {
						//country_id:'Trust me, i am working',
						action:'getstate',
						country_id: country_id
						
					},

					success:function(data,textStatus,XMLHTTPRequest)
					{
						data = JSON.parse(data);
						//console.log(data);
						//var temp = "<option>"+data.id+"</option>";
						//var temp = "<option>"+data.states+"</option>";
						jQuery('#select_state').html(data.states);
						//jQuery('#select_state').append(data.states);
						/*console.log(textStatus);
						console.log(XMLHTTPRequest);*/
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown)
					{
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					}
				});
			});

			jQuery('.state').on('change',function()
			{
				jQuery('#select_city').show();
				var state_id = jQuery(this).val();
				jQuery.ajax
				({
					type: 'POST',
					url: ajax_call.ajaxurl,
					data: {
						//country_id:'Trust me, i am working',
						action:'getcity',
						state_id: state_id
						
					},

					success:function(data,textStatus,XMLHTTPRequest)
					{
						data = JSON.parse(data);
					
						jQuery('#select_city').html(data.city);
						//jQuery('#select_city').append(data.city);
						
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown)
					{
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					}
				});
			});

			jQuery('.state').on('change',function()
			{	
				//var state_id = jQuery(this).val();
				/*jQuery('#select_state').show();
				//var id = $(this).val();
				var country_id = jQuery('#select_state').val();
				
				
				jQuery.ajax
				({
					type: 'POST',
					//url: 'my-ajax.php',
					//url: '<?php $this->ajax_path(); ?>',
					url: ajaxurl,
					data: {
						country_id:country_id,
						action:'getstate',
						
					},

					success:function(data,textStatus,XMLHTTPRequest)
					{
						console.log(data);
						jQuery('#select_state').append(data);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown)
					{
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					}
				});*/
			});


			jQuery("#select_state").change(function()
			{
				/*jQuery("#select_city").show();
				var city_id = jQuery("#select_city").val();
				//$("#select_city").css("display:block;");
				
			
				jQuery.ajax
				({
					type: 'POST',
					//url: 'my-ajax.php',
					url: '<?php $this->ajax_path(); ?>',
					data: {
						city_id: city_id,
						action: 'getcity',
						
					},

					success:function(data,textStatus,XMLHTTPRequest)
					{
						console.log(data);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					},
					error:function(XMLHTTPRequest,textStatus,errorThrown)
					{
						console.log(errorThrown);
						console.log(textStatus);
						console.log(XMLHTTPRequest);
					} 
				});*/
			}); 

		}); // jquery end