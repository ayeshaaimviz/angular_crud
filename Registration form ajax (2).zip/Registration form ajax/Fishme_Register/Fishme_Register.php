<?php
ob_start();
/**
 * @package Fishme_Register
 * @version 4.4
 */
/*
Plugin Name: Fishme_Register
Plugin URI: https://wordpress.org/plugins/Fishme_Register/
Description: Contact Form 7 can manage multiple contact forms, plus you can customize the form and the mail contents flexibly with simple markup.
Version: 4.4
Author URI: http://localhost/
*/
function ajax_registration_dependency() 
	{
	 wp_enqueue_script('my-js', plugin_dir_url( __FILE__ ).'sc.js', array('jquery')); 	// use for file include
	 wp_localize_script('my-js', 'ajax_call', array('ajaxurl' => admin_url('admin-ajax.php')));	//use for define global variable
	}

	add_action('wp_enqueue_scripts', 'ajax_registration_dependency');

	function create_form()
	{
	
		global $wpdb;
			$state = $wpdb->get_results('select state_name from wp_state');
			$country = $wpdb->get_results('select wp_country.*  from wp_country');
			$city = $wpdb->get_results('select city_name from wp_city');
		?>
		<button id='btn'>Click Me</button>
		<form class="ink_form" method="POST" accept-charset="utf-8">

		<label> Company Name </label>
			<input type="text" name="comp_name" id="comp_name" placeholder="Charter Company Name" required="required" > </br></br>

			<label> Full Name</label>
			 <input type="text" name="full_name" id="full_name" placeholder="Full Name" required="required"  > </br></br>

			<label>Email </label>
			 <input type="text" name="email" id="email" placeholder="Email" required="required"> </br></br>

			<label> Telephone </label>
			 <input type="text" name="phone" id="phone" placeholder="Telephone" required="required"> </br></br>
			<!-- <label> Select Country</label> -->
			<select name="country" id="select_country" class="country">
				<option value="">Select Your Country</option>
				<?php
				foreach ($country as $key) 
				{
					?>
					<option value="<?php echo $key->id; ?>"><?php echo $key->country_name; ?> </option>
					<?php
				}
			 	?>
			</select></br></br>

			<!-- <label> Select State</label> -->
			<select name="state" id="select_state" class="state">
				<option value="">Select Your State</option>
			</select></br></br>

			<!-- <label> Select City</label> -->
			<select name="city" id="select_city" class="city">
				<option value="">Select Your City</option>
			</select></br></br>

			<label>	Address</label>
		 	<input type="text" name="address" id="address" placeholder="Address" required="required"> </br></br>

			<label> Password</label>
			 <input type="password" name="pass" id="pass" placeholder="Password" required="required"> </br> </br>

			<label>Repeat Password </label>
			<input type="password" name="re_pass" id="re_pass" placeholder="Repeat Password" required="required"> </br> </br>

			<input type="submit" name="submit" value="Submit" >
		</form>


		<?php
	} //end function

	add_shortcode('create_form', 'create_form');

	/*function ajax_path()
	{
		$x = plugin_basename( __FILE__ );
		echo $x;
		echo "<br>";

		$plugins_url = plugins_url();
		echo $plugins_url;	
		echo "<br>";

		$url = plugin_dir_url( __FILE__  );
		return $url."my-ajax.php" ;
	}

	add_shortcode('path','ajax_path');*/


	add_action('wp_ajax_getstate','getstate');

	function getstate()
	{
		$res = array(); //associative arrray
		$res['output_state'] = $_POST['country_id'];

		if($_POST['country_id'])
        {
            $id=$_POST['country_id'];

            global $wpdb;
            //$country = $wpdb->get_results('select * from wp_state WHERE country_id='.$id);
            //echo 'SELECT wp_state.* FROM wp_state WHERE wp_state.coutry_id='.$id;
            $country = $wpdb->get_results('SELECT wp_state.* FROM wp_state WHERE wp_state.coutry_id='.$id);
            //var_dump($country);
            foreach ($country as $key => $value) 
            {
            	
              $res['states'][] ='<option value="'.$value->id.'">'.$value->state_name.'</option>';
                
            }
        	
		
		}
		print_r(json_encode($res));
		die();
	}

add_action('wp_ajax_getcity','getcity');

	function getcity()
	{
		$res = array(); //associative arrray
		$res['output_city'] = $_POST['state_id'];

		if($_POST['state_id'])
        {
            $id=$_POST['state_id'];

            global $wpdb;
            
             //$country = $wpdb->get_results('select wp_city.* from wp_city WHERE state_id='$id);
             $city = $wpdb->get_results('SELECT wp_city.* FROM wp_city WHERE wp_city.state_id='.$id);
            
            foreach ($city as $key => $value) 
            {
               
               $res['city'][] ='<option value="'.$value->id.'">'.$value->city_name.'</option>';
               
            }  
        	
		
		}
		print_r(json_encode($res));
		die();
	}


	


?>