<?php

/*echo   plugin_dir_path ( __FILE__ );

echo   plugin_dir_url ( __FILE__ );

$plugins_url = plugins_url();
print_r($plugins_url);
*/

$x = plugin_basename( __FILE__ );
echo $x;
?>