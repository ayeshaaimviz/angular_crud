
				jQuery(document).ready(function()
				{
				    jQuery("#join_game").click(function(e)
				    {
						e.preventDefault();
				        var user_div = jQuery("#user_div").val();
				        var post_id = jQuery("#post_id").val();
				        var user_id = jQuery("#user_id").val();
				        var user_list = jQuery("#user_list").val();



						jQuery.ajax({
							type: 'POST',
							url: 'single-game-ajax.php',
							data: {
								action:'gamejoin',
								user_div:user_div,
								post_id:post_id,
								user_id:user_id,
								user_list:user_list

							},
							success:function(data,textStatus,XMLHTTPRequest)
							{
								data = JSON.parse(data);
								console.log(data);

								jQuery('#user_list').html(data.user_id);
								//jQuery('#lover_list').html(data.user_id);
								
								
							},
							error:function(XMLHTTPRequest,textStatus,errorThrown)
							{
								console.log(errorThrown);
								console.log(textStatus);
								console.log(XMLHTTPRequest);
							}

						});	//ajax end

				    }); 	//on click end

				});	//doc ready end


		