<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 

function ajax_game_join() 
	{
	 wp_enqueue_script('my-join', plugin_dir_url( __FILE__ ).'single-game.js', array('jquery')); 	// use for file include
	 wp_localize_script('my-join', 'ajax_call_join', array('ajax_join_url' => admin_url('admin-ajax.php')));	//use for define global variable
	}


	add_action('wp_enqueue_scripts', 'ajax_game_join');
?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_format() );

			// End the loop.
			endwhile;
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
				'next_text'          => __( 'Next page', 'twentysixteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
<?php
/*add_shortcode('games_form','games_form');
add_action('wp_ajax_games_form','games_form');
		function games_form()
		{*/

?>
			<!-- Total Likes : <?php echo get_post_meta(get_the_ID(),'like',true);?> -->
			<form action="" method="POST" name="join_form" id="join_form">
				<input type="text" id="post_id" name="post_id" value="<?php echo get_the_ID(); ?>">
				<input type="text" name="user_id" id="user_id" value="<?php echo get_current_user_id(); ?>">

				<input type="submit" id="join_game"  name="join_game" value="Join"/></br></br>

				<div id="user_div" name="user_div" value="">

					<ol name="user_list" id="user_list" value="<?php echo get_current_user_id(); ?>">
						<li>Faizyab</li>
					</ol>
				</div>

			</form>
		<?php

		/*}*/

add_action('wp_ajax_gamejoin','gamejoin');

function gamejoin()
{
	$res = array();
	//$res['user_div'] =wp_strip_all_tags($_POST['user_div']);
	$res['post_id'] =wp_strip_all_tags($_POST['post_id']);
	var_dump($res['post_id']);

	$res['user_id'] =wp_strip_all_tags($_POST['user_id']);
	var_dump($res['user_id']);

	//$res['user_list'] =wp_strip_all_tags($_POST['user_list']);
	
			//$countLikes = get_post_meta($_POST['add'],'like',true);
			
			$meta_key = 'join';
			$meta_value = $res['user_id'];
			
	

			$res['new_post_meta'] = add_post_meta($res['post_id'],$meta_key ,$meta_value);

			print_r($res['new_post_meta']);


	print_r(json_encode($res));
	die();

}
		?>

		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
