<?Php
ob_start();
/**
 * @package Game_join
 * @version 4.4
 */
/*
Plugin Name: Game_join
Plugin URI: https://wordpress.org/plugins/Game_join/
Description: Contact Form 7 can manage multiple contact forms, plus you can customize the form and the mail contents flexibly with simple markup.
Version: 4.4
Author URI: http://localhost/
*/


function ajax_game() 
{
 wp_enqueue_script('my-joingame', plugin_dir_url( __FILE__ ).'Game_join.js', array('jquery')); 	// use for file include
 wp_localize_script('my-joingame', 'ajax_call_joingame', array('ajax_joingame_url' => admin_url('admin-ajax.php')));	//use for define global variable
}

	
	add_action('wp_enqueue_scripts', 'ajax_game');

//add_action('wp_ajax_join_form','join_form');

add_shortcode('join_form','join_form');

function join_form()
{
	?>
	<form action="" method="POST" name="form1" id="form1">

			<input type="text" name="p_id" id="p_id" value="<?php echo get_the_ID(); ?>"> <!-- post_id -->

			<input type="text" name="join_user_id" id="join_user_id" value="<?php echo get_current_user_id(); ?>">	<!-- user_id --> 

			<input type="text" name="joining_name" id="joining_name" value="<?php $user = get_user_by('ID' , get_current_user_id()); echo $user->display_name; ?>">	<!-- user name  -->
			
			<input type="text" id="join_post_meta" name="join_post_meta" value="<?php $post_id = get_the_ID(); $meta_key = 'join'; $user_id = get_current_user_id(); echo update_post_meta($post_id,$meta_key,$user_id); ?>">

			<input type="submit" name="join_game" id="join_game" value="Join+">

			<ol name="gaming_list" id="gaming_list">
				<li value="list" id="list"></li>
			</ol>
			<!-- <div name="users" id="users">
				
			</div> -->
		</form>
	<?php
}

/*add_action('wp_ajax_gameuser','gameuser');

function gameuser()
{
	$res = array();
	$res['joining_name'] = wp_strip_all_tags($_POST['joining_name']);
	var_dump($res['joining_name']);

	print_r(json_encode($res));
	die();
}*/

?>