<?php
/**
 * The template for displaying archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * If you'd like to further customize these archive views, you may create a
 * new template file for each one. For example, tag.php (Tag archives),
 * category.php (Category archives), author.php (Author archives), etc.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<?php

/*function ajax_game() 
	{
	 wp_enqueue_script('my-joingame', plugin_dir_url( __FILE__ ).'single-game-ajax.js', array('jquery')); 	// use for file include
	 wp_localize_script('my-joingame', 'ajax_call_joingame', array('ajax_joingame_url' => admin_url('admin-ajax.php')));	//use for define global variable
	}

	
	add_action('wp_enqueue_scripts', 'ajax_game');*/
?>


	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<?php
					the_archive_title( '<h1 class="page-title">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				?>
			</header><!-- .page-header -->

			<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_format() );

			// End the loop.
			endwhile;
			// Previous/next page navigation.
			the_posts_pagination( array(
				'prev_text'          => __( 'Previous page', 'twentysixteen' ),
				'next_text'          => __( 'Next page', 'twentysixteen' ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>',
			) );

		// If no content, include the "No posts found" template.
		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
		<script type="text/javascript">
			jQuery(document).ready(function()
			{
				 jQuery('#users').hide();
				 jQuery('#text').hide();
				 jQuery('#user_id').hide();
				 jQuery('#user_name').hide();
				jQuery('#join_game').click(function(e)
				{
					e.preventDefault();
					//alert('you have joined this game');
					var text = jQuery('#text').val();
					var user_id = jQuery('#user_id').val();
					var users = jQuery('#users').val();
					var user_name = jQuery('#user_name').val();
					console.log(text);
					console.log(user_id);
					console.log(users);
					console.log(user_name);

					 jQuery('#users').show();
					var join_user = jQuery('#list').html(user_name);

				});
			});
		</script>

		<form action="" method="POST">

			<input type="text" name="text" id="text" value="<?php echo get_the_ID(); ?>">

			<input type="text" name="user_id" id="user_id" value="<?php echo  get_current_user_id(); ?>">

			<input type="text" name="user_name" id="user_name" value="<?php $user = get_user_by('ID' , get_current_user_id()); echo $user->display_name; ?>">

			<input type="submit" name="join_game" id="join_game" value="Join+">

			<ol name="users" id="users">
				<li value="list" id="list"></li>
			</ol>
			<!-- <div name="users" id="users">
				
			</div> -->
		</form>
		<?php
		/*if (isset($_POST['join_game'])) 
		{

			$user_id = get_current_user_id();
			//print_r($user_id);
			echo "<br>";
			$user = get_user_by( 'ID', $user_id );
			//print_r($user);
			$game_user = $user->display_name ;
			echo '<ol>' . "Joined Users";
			echo '<li>' . $game_user . '</li>';
			echo '</ol>';
			echo "<br>";

			$post_id= get_the_ID();
			//print_r($post_id);
			//echo "<br>";
			$meta_key = 'Join_Game';
			$meta_value = $game_user;

			$game_user_id = add_post_meta($post_id,$meta_key ,$meta_value);
			
		}
*/		?>



