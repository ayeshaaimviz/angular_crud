jQuery(document).ready(function()
{
	jQuery('#join_game').click(function()
	{
		//e.preventDefault();
		alert('working');
		/*var text = jQuery('#text').val();
		var user_id = jQuery('#user_id').val();
		var users = jQuery('#users').val();
		console.log(text);
		console.log(user_id);
		console.log(users);
		jQuery('#users').html(user_id);*/
	});




});